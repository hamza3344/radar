﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace radarchat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double[,] values = {{ 664 , 183 ,20 , 5,   15 , 0 },
                { 464 , 142, 19,  3,   9,   7 }, };
            var radar = formsPlot1.Plot.AddRadar(values, independentAxes: true);
            radar.CategoryLabels = new string[] { "Mat", "Series", "Awards", "Tests", "ODIs", "T20Is" };
            radar.GroupLabels = new[] { "SR Tendulkar", "V Kohli" };
            formsPlot1.Plot.Title("2 player comparsion");
            formsPlot1.Plot.Legend();
            formsPlot1.Refresh();
        }
    }
}
